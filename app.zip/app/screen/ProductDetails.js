import React, { useEffect, Component, useState } from 'react';
import EvilIcons from 'react-native-vector-icons/EvilIcons';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import AntDesign from 'react-native-vector-icons/AntDesign';

import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ImageBackground,
  Image,
  ScrollView,
} from 'react-native';
import * as actions from '../redux/action/actions';
import { useDispatch, useSelector } from 'react-redux';
import { BASE_URL } from '../helper/Const';

export default function ProductDetails({ route, navigation }) {
  const dispatch = useDispatch();

  const { storeId } = route.params;
  console.log('>>>>>>>>>>> ', route.params)

  useEffect(() => {
    dispatch(
      actions.fetchStoreDetails({
        store_id: storeId,
      }),
    );
  }, []);

  const {storeDetails, storeDetailsLoading} = useSelector(state => ({
    storeDetails: state.dashboardReducer.storeDetails,
    storeDetailsLoading: state.dashboardReducer.storeDetailsLoading,
  }));

  useEffect(() => {
    console.log('storeDetails ', storeDetails);
  }, [storeDetails]);

  

  return (
    <>
      <View style={{ flex: 1 }}>
        {storeDetailsLoading ? (
          <Text style={{ alignSelf: 'center', marginTop: 20, fontSize: 24 }}>
            Loading...
          </Text>
        ) : (
          <>

            <View style={{ flex: 1, backgroundColor: '#f5f5f5', paddingHorizontal: 20 }}>
              <View
                style={{
                  width: "100%",
                  height: 213,
                  backgroundColor: '#fff',

                  marginTop: 20,
                  borderRadius: 10,
                }}>
                <Image
                  source={require('../image/products.png')}
                  style={{ height: 213, width: 345 }}
                // source={{uri: BASE_URL+storeDetails.image }}
                // source={{uri: "http://talc.ubicoapps.in/storage/product/1626544992.jpg" }}
                />
              </View>
              <View style={{}}>
                <Text
                  style={{
                    marginTop: 15,
                    fontWeight: 'bold',
                  }}>
                  {storeDetails && storeDetails.name}
                </Text>
                <Text
                  style={{
                    marginTop: 10,
                    fontWeight: 'bold',
                    color: '#F97762',
                  }}>
                  ${storeDetails && storeDetails.price}
                </Text>
                <Text
                  style={{
                    marginTop: 10,
                    fontWeight: 'bold',
                  }}>
                  Product Details
                </Text>
                <ScrollView
                  style={{
                    width: "100%",
                    height: 185,
                    backgroundColor: '#FFFFFF',
                    borderRadius: 10,
                    marginTop: 10
                  }}>
                  <Text
                    style={{
                      color: '#6B6B7B',
                      paddingHorizontal: 20,
                      fontSize: 12,
                    }}>
                    {storeDetails && storeDetails.subtitle}
                  </Text>
                  <Text
                    style={{
                      color: '#6B6B7B',
                      fontSize: 12,
                      marginTop: 15,
                    }}>
                    {storeDetails && storeDetails.description}
                  </Text>

                </ScrollView>
              </View>
            </View>

            <View
              style={{ flexDirection: "row", height: 100, width: "100%", backgroundColor: "#fff"
              , position: 'absolute', bottom: 0 ,justifyContent:"center",alignItems:"center",}}>

              <TouchableOpacity 
               activeOpacity={1}
               style={{
                backgroundColor: '#F97762',
                width: 165,
                height: 48,
                borderRadius: 10,
                marginRight:10,
                justifyContent:"center",
                alignItems:"center",
                marginBottom:10

              }} onPress={() => navigation.navigate('Cart')}>
                <Text
                  style={{
                    color: 'white'
                  }}>
                  Add to cart
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
               activeOpacity={1}
                style={{
                  backgroundColor: '#04A768',
                  width: 165,
                  height: 48,
                  borderRadius: 10,
                  marginLeft:10,
                  justifyContent:"center",
                  alignItems:"center",
                  marginBottom:10
                }}
                onPress={() => navigation.navigate('Payment')}>
                <Text
                  style={{
                    color: 'white',
                    
                  
                  }}>
                  Buy Now
                </Text>
              </TouchableOpacity>

            </View>

            {/* <View style={{flexDirection: 'row', }}>
                <View
                  style={{
                    backgroundColor: '#F97762',
                    width: 165,
                    height: 48,
                    borderRadius: 10,
                  
                  }}>
                  <TouchableOpacity onPress={() => navigation.navigate('')}>
                    <Text
                      style={{
                        color: 'white',
                        textAlign: 'center',
                        marginTop: 12,
                      }}>
                      Add to cart
                    </Text>
                  </TouchableOpacity>A
                </View>
              
              <View style={{flexDirection: 'row', marginTop: 120}}>
                <View
                  style={{
                    backgroundColor: '#04A768',
                    width: 165,
                    height: 48,
                    borderRadius: 10,
                  
                  }}>
                  <TouchableOpacity onPress={() => navigation.navigate('Cart')}>
                    <Text
                      style={{
                        color: 'white',
                        textAlign: 'center',
                        marginTop: 12,
                      }}>
                      Buy Now
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View> */}
          </>
        )}
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  checkboxContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
});
