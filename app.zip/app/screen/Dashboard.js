import React, { useEffect, Component, useState } from 'react';

import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ImageBackground,
  Image,
  ScrollView,
  SafeAreaView,
} from 'react-native';
import ProgressCircle from 'react-native-progress-circle';
import Slick from 'react-native-slick';
import { SliderBox } from 'react-native-image-slider-box';
import { FlatList } from 'react-native-gesture-handler';
import { color } from 'react-native-reanimated';
import CircularProgress from "react-native-circular-progress-indicator"
import { useDispatch, useSelector } from 'react-redux';
import * as actions from '../redux/action/actions';
import { navigationRef } from '../navigations/navigationref';
export default function Dashboard({ navigation }) {
  const [text, onChangeText] = React.useState(null);
  const [sessionCompleted, setSessionCompleted] = useState(10)
  const [totalSession, setTotalSession] = useState(40)
  const [courseDuration, setCourseDuration] = useState(0)
  const [coursefee, setCoursefee] = useState(0) 
  const dispatch = useDispatch();


  const [name, setName] = useState('')

  const { profileData } = useSelector((state) => ({
    profileData: state.dashboardReducer.profileData
  }));

  const { isLoading, dashboard } = useSelector((state) => ({
    isLoading: state.authReducers.isLoading,
    dashboard: state.authReducers.dashboard
  }));
  console.log("🚀 ~ file: Dashboard.js ~ line 32 ~ const{isLoading,dashboard}=useSelector ~ dashboard", dashboard)

  const onDashboard = () =>
    dispatch(actions.dashboard());

  // ComponentDidMount -> After Render -> One Time only  
  useEffect(() => {
    dispatch(actions.getUserProfile());
    onDashboard()
  }, [])


  useEffect(() => {
    console.log("profileData",profileData)
  }, [profileData]
  )





  

  // When the variable inside the array changes
  useEffect(() => {
  const challenge =  dashboard?.challenge?.[0] ?? {}
  setCoursefee(challenge.price ?? 0)
  setCourseDuration(challenge?.duration ?? 0)
  console.log("🚀 ~ file: Dashboard.js ~ line 47 ~ useEffect ~ challenge", challenge)
  }, [dashboard])

  const _renderItem = ({ item }) => {
    console.log("item", item)
    return (
      <View style={{ height: 200, marginHorizontal: 10 }}>
        <Image style={{ width: 200, height: 123, borderRadius: 10 }}
          source={{ uri: `http://talc.ubicoapps.in/${item.image}` }}
        />
        <Text style={{ fontSize: 12, fontWeight: 'bold', marginTop: 5 }}>{item.title}</Text>
        <Text style={{ fontSize: 12, marginTop: 5, color: "red" }}>${item.price}</Text>

      </View>
    );
  };

  const _keyExtractor = (item, index) => item.key;

  return (
    <>
      <ScrollView style={{ flex: 1, backgroundColor: '#0000001F' }}>
        <SafeAreaView>
          <View style={{ marginLeft: 12 }}>
            <View style={{ flexDirection: 'row' }}>
              <Text
                style={{
                  fontSize: 24,
                  color: '#000',
                  fontWeight: 'bold',
                  marginTop: 50,
                  marginLeft: 15,
                }}>
                Hello,
              </Text>
              <Text
                style={{
                  fontSize: 24,
                  color: '#F97762',
                  fontWeight: 'bold',
                  marginTop: 50,
                  marginLeft: 5,
                }}>
                {profileData?.name}
              </Text>
              <View
                style={{
                  width: 38,
                  height: 38,
                  backgroundColor: '#fff',
                  borderRadius: 10,
                  marginTop: 10,
                  marginLeft: 80,
                  marginTop: 45,
                  justifyContent: 'center',
                }}>
                  <TouchableOpacity
                  onPress={()=>navigation.navigate("Notification")}>
                <Image
                  source={require('../image/dashboard.png')}
                  style={{ width: 18, height: 19, marginLeft: 10 }}
                />
                </TouchableOpacity>
              </View>
              <TouchableOpacity
                  onPress={()=>navigation.navigate("Profile")}>
              <Image
                source={require('../image/edit.png')}
                style={{ width: 38, height: 38, marginLeft: 10, marginTop: 45 }}
              />
              </TouchableOpacity>
            </View>
            <View
              style={{
                width: 335,
                height: 180,
                backgroundColor: '#fff',
                borderRadius: 15,
                marginTop: 20,
                marginHorizontal: 15,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  marginTop: 20,
                  justifyContent: 'center',
                }}>
                <Text style={{ color: '#9B9BA8' }}>Course Duration</Text>
                <Text style={{ marginLeft: 10, color: '#9B9BA8' }}>
                  Session Left
                </Text>
                <Text style={{ marginLeft: 10, color: '#9B9BA8' }}>
                  Course Fee
                </Text>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  marginTop: 10,
                  justifyContent: 'center',
                  alignSelf: 'center',
                }}>
                <Text
                  style={{
                    color: '#000',
                    fontSize: 16,
                    fontWeight: 'bold',
                    marginLeft: 1,
                  }}>
                  {`${courseDuration}`}
                </Text>
                <Text
                  style={{
                    marginLeft: 10,
                    color: '#000',
                    fontSize: 16,
                    fontWeight: 'bold',
                    marginLeft: 40,
                  }}>
                  {sessionCompleted}/{totalSession}
                </Text>
                <Text
                  style={{
                    marginLeft: 10,
                    color: '#000',
                    fontSize: 16,
                    fontWeight: 'bold',
                    marginLeft: 60,
                  }}>
                  {coursefee}
                </Text>
              </View>
              <View
                style={{
                  width: 335,
                  height: 1,
                  backgroundColor: '#0000000F',
                  marginTop: 20,
                  marginBottom: 20,
                }}></View>
              <View style={{ flexDirection: 'row' }}>
                <Text
                  style={{
                    fontSize: 16,
                    color: '#F97762',
                    marginLeft: 50,
                    marginBottom: 6,
                  }}>
                  My Life Group 1
                </Text>
                <View style={{ marginLeft: 80, marginTop: -10 }}>
                 
                <CircularProgress value={totalSession === 0 ? 0 : parseInt(sessionCompleted*100/totalSession)} 
                   strokeWidth={90}
                   radius={40}
                   duration={2000}
                   activeStrokeColor={'#F97762'}
                   inActiveStrokeColor={'grey'}
                   inActiveStrokeOpacity={0.2}
                   textColor={'black'}
                   valueSuffix={'%'}
                   fontSize={14}
                   onAnimationComplete={() => { console.log('callback') }}
                   textStyle={{ fontWeight: 'bold', color: 'yellow' }}
                   />
                </View>
              </View>
              <Text
                style={{
                  fontSize: 12,
                  color: '#9B9BA8',
                  marginLeft: 50,
                  marginTop: -30,
                }}>
                Brief introduction of courses
              </Text>
            </View>
            <View style={{ flexDirection: 'row', marginTop: 30 }}>
              <Text
                style={{
                  color: '#1C1F21',
                  fontSize: 20,
                  fontWeight: 'bold',
                  marginLeft: 10,
                }}>
                Popular Sessions
              </Text>
              <TouchableOpacity onPress={()=>navigation.navigate("Sessions")}>
              <Text
                style={{
                  color: '#F97762',
                  fontSize: 14,
                  fontWeight: 'bold',
                  marginLeft: 130,
                }}>
                View All
              </Text>
              </TouchableOpacity>
            </View>

            <FlatList
              horizontal
              style={{ marginTop: 10 }}
              nestedScrollEnabled
              data={dashboard?.course}
              showsVerticalScrollIndicator={false}
              keyExtractor={_keyExtractor}
              renderItem={_renderItem}
              showsHorizontalScrollIndicator={false}
            />

            <View style={{ flexDirection: 'row' }}>
              <Text
                style={{
                  fontSize: 20,
                  color: '#000',
                  marginTop: 10,
                  marginLeft: 10,
                  fontWeight: 'bold',
                  marginLeft: 10,
                }}>
                Store
              </Text>
                <TouchableOpacity onPress={()=>navigation.navigate("Sessions")}>
              <Text
                style={{
                  fontSize: 14,
                  color: '#F97762',
                  marginTop: 10,
                  marginLeft: 10,
                  fontWeight: 'bold',
                  marginLeft: 225,
                }}>
                View All
              </Text>
              </TouchableOpacity>
            </View>
          </View>
        </SafeAreaView>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  checkboxContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
});

