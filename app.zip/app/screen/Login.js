import React, {useEffect, Component, useState} from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ImageBackground,
  Image,
} from 'react-native';
import * as actions from '../redux/action/actions';
import {useDispatch, useSelector} from 'react-redux';


export default function Login({navigation}) {
  const [email, setemail] = React.useState('');
  const [password, setpassword] = React.useState('');
  const [checked, setChecked] = React.useState('first');

  const dispatch = useDispatch();
  const {isLoading} = useSelector(state => ({
    isLoading: state.authReducers.isLoading,
  }));

  const onLogin = () => dispatch(actions.login({email, password}));

  return (
    <ImageBackground
      source={require('../image/background.png')}
      style={{flex: 1, justifyContent: 'center', backgroundColor: '#612C58'}}>
      <>
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignSelf: 'center',
            marginBottom: 90,
          }}>
          <View style={{marginHorizontal: 12}}>
            <View style={{flexDirection: 'row', marginBottom: 50}}>
              <Image
                source={require('../image/logo.png')}
                style={{width: 142.22, height: 60, marginLeft: -10}}
              />
              <TouchableOpacity
                onPress={() => navigation.navigate('BottomNavi')}
                style={{
                  width: 70,
                  height: 36,
                  backgroundColor: 'rgba(255, 255, 255, 0.3)',
                  borderRadius: 10,
                  marginLeft: 130,
                  marginTop: 20,
                  justifyContent:"center"
                }}>
                <Text
                  style={{
                    color: 14,
                    textAlign: 'center',
                  
                    color: 'white',
                  }}>
                  Skip
                </Text>
              </TouchableOpacity>
            </View>

            <View style={{marginTop: 20}}>
              <Image
                source={require('../image/login1.png')}
                style={{width: 150, height: 83}}
              />
              <View
                style={{flexDirection: 'row', marginTop: 15, marginBottom: 25}}>
                <Text style={{fontSize: 14, color: '#E8DEE6'}}>
                  If you are new?
                </Text>
                <TouchableOpacity
                onPress={()=>navigation.navigate("Singup")}>
                <Text style={{fontSize: 14, color: '#F97762',fontWeight:"bold"}}>
                  {' '}
                  Create an Account
                </Text>
                </TouchableOpacity>
              </View>
              <Text
                style={{
                  fontSize: 14,
                  color: '#E8DEE6',
                  marginTop: 40,
                  marginBottom: 20,
                }}>
                Email
              </Text>
              <View
                style={{
                  width: "100%",
                  height: 48,
                  borderRadius: 10,
                  backgroundColor: '#ffff',
                  justifyContent:"center"
                }}>
                <TextInput
                style={{marginLeft:10}}
                  onChangeText={e => setemail(e)}
                  value={email}
                  placeholder=""
                />
              </View>
              <Text
                style={{
                  fontSize: 14,
                  color: '#E8DEE6',
                  marginTop: 15,
                  marginBottom: 20,
                }}>
                Password
              </Text>
              <View
                style={{
                  width: "100%",
                  height: 48,
                  borderRadius: 10,
                  backgroundColor: '#ffff',
                  justifyContent:"center",
                   

                }}>
                <TextInput
                style={{marginLeft:10}}
                  onChangeText={e => setpassword(e)}
                  value={password}
                  placeholder=""
                   secureTextEntry={true}
                
                />
              </View>
            </View>
            <View>
              <View style={{flexDirection: 'row', marginTop: 25}}>
                <TouchableOpacity
                  onPress={() => navigation.navigate('Forgot Password')}>
                  <Text
                    style={{paddingLeft: 10, color: '#FFFFFF', marginTop: 15}}>
                    Forgot Password?
                  </Text>
                </TouchableOpacity>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginLeft: 70,
                  }}>
                    <TouchableOpacity onPress={onLogin}
                    activeOpacity={0.6}
                    style={{
                      backgroundColor: '#F97762',
                      width: 116,
                      height: 48,
                      borderRadius: 10,
                      marginLeft: 22,
                      justifyContent:'center',
                      alignItems:"center",
                    }}>
                
                      <Text
                        style={{
                          color: 'white',
                        }}>
                        Login
                      </Text>
                    </TouchableOpacity>
                
                </View>
              </View>
            </View>
          </View>
        </View>
      </>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  checkboxContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
});
