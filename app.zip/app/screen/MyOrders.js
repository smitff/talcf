import React, { useEffect, Component, useState } from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ImageBackground,
  Image,
  ScrollView,
  FlatList
} from 'react-native';
import * as actions from '../redux/action/actions';
import { useDispatch, useSelector } from 'react-redux';

export default function MyOrders({ navigation }) {

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(actions.getOrder());
  }, [])

  const { getOrderLoader, getOrderList } = useSelector((state) => ({
    getOrderList: state.dashboardReducer.getOrderList,
    getOrderLoader: state.dashboardReducer.getOrderLoader
  }));

  useEffect(() => {
    console.log("Store -> getOrderList", getOrderList)
  }, [getOrderList, getOrderLoader])

  const _renderItem = (item, index) => {
    console.log("itemitem", item)
    return (

      <View style={{
        flexDirection: 'row',
        width: 345,
        height: 110,
        backgroundColor: 'white',
        borderRadius: 10,
        marginTop: index !== 0 ? 20 : 0,
        marginTop: 20,
      }}>
        <View style={{ backgroundColor: "white", height: 110, width: "30%", justifyContent: "center", alignItems: "center" }}>
          <Image
            source={require('../image/card1.png')}
            style={{
              width: 70,
              height: 80,
              borderRadius: 6,
              borderBottomColor: "grey",
              borderBottomWidth: 2
            }}
          />
        </View>

        <View style={{ backgroundColor: "whiote", height: 110, width: "70%", justifyContent: "center", }}>

          <Text
            style={{
              color: '#17212A',
              fontSize: 14,
              fontWeight: 'bold',
              marginLeft: 10,
              marginTop: 10
            }}>
            Building The Business Brainn
          </Text>

          <Text
            style={{
              color: '#F97762',
              fontSize: 12,
              marginLeft: 10,
              marginTop: 10
            }}>
            ${item.price}
          </Text>

          <Text
            style={{
              color: '#F97762',
              fontSize: 14,
              color: '#04A768',
              fontWeight: 'bold',
              marginTop: 10,
              marginLeft: 10
            }}>
            Order Confirmed
          </Text>

        </View>
      </View>

    )
  }

  return (
    <>
      <View
        style={{
          flex: 1,
          backgroundColor: '#F5F5F5',
          justifyContent: 'center',
          alignSelf: 'center',
          paddingHorizontal: 20
        }}>
        <FlatList
          data={getOrderList?.user_store}
          showsVerticalScrollIndicator={false}
          renderItem={({ item, index }) => _renderItem(item)}
        />
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  checkboxContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
});

// import React, { useEffect, Component, useState } from 'react';
// import { RadioButton, CheckBox } from 'react-native-paper';
// import {
//     StyleSheet,
//     View,
//     Text,
//     TouchableOpacity,
//     TextInput,
//     ImageBackground,
//     Image
// } from 'react-native';

// export default function Login({ navigation }) {
//     const [text, onChangeText] = React.useState(null);

//     return (
//         <>
//             <View style={{ flex: 1, backgroundColor: '#F5F5F5',justifyContent:"center" }}>
//                 <View style={{ marginHorizontal: 12 }}>
//                     <View style={{ flexDirection: "row" }}>
//                         <Image
//                             source={require('../image/order.png')}
//                             style={{ width: 430, height: 130, marginTop: 8, marginLeft: -46 }}
//                         />
//                     </View>
//                     <View style={{ flexDirection: "row" }}>
//                         <Image
//                             source={require('../image/order.png')}
//                             style={{ width: 430, height: 130, marginLeft: -46 }}
//                         />
//                     </View>
//                     <View style={{ flexDirection: "row" }}>
//                         <Image
//                             source={require('../image/order.png')}
//                             style={{ width: 430, height: 130, marginLeft: -46 }}
//                         />
//                     </View>
//                     <TouchableOpacity onPress={() => navigation.navigate('Package')}>
//                         <View style={{ width: 134, height: 5, backgroundColor: "#E3E2E3", borderRadius: 10, marginTop: 240, justifyContent: "center", alignSelf: "center" }}></View>
//                     </TouchableOpacity>
//                 </View>
//             </View>
//         </>
//     );
// };
// const styles = StyleSheet.create({
//     checkboxContainer: {
//         flexDirection: "row",
//         marginBottom: 20,
//     },
// });
