import React, { useEffect, Component, useState } from 'react';
import { RadioButton, CheckBox } from 'react-native-paper';

import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ImageBackground,
  Image,
} from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import SelectDateTimes from './SelectDateTimes';

export default function Payments({ navigation }) {
  let paypalSelected = true, amazonSelected = false
  const paymentSelected = (method) => {
    if (method === 'paypal') {
      // debitSelected = false
      paypalSelected = true
      // amazonSelected = false
    }
  }

  return (

    <>
      <View
        style={{
          flex: 1,
          backgroundColor: '#F5F5F5',


          paddingHorizontal: 20
        }}>
        <Text
          style={{

            marginTop: 20,
            color: '#000',
            fontWeight: 'bold',
          }}>
          Select Payment Method
        </Text>
        {/* <View
          style={styles.selectionView}>
          <View style={{ flexDirection: 'row' }}>
            <Image
              source={require('../image/debitcard.png')}
              style={{ width: 20, height: 15, marginLeft: 8 }}
            />
            <Text style={{ marginLeft: 30 }}>
              Debit or Credit Card
            </Text>
            <TouchableOpacity
              onPress={()=>paymentSelected('debit')}
              style={[styles.selection,{borderColor: debitSelected  ? '#EA8C12' : '#43484d'}]}></TouchableOpacity>
          </View>
        </View> */}

        <View
          style={styles.selectionView}>
          <View style={{ flexDirection: 'row' }}>
            <Image
              source={require('../image/paypal.png')}
              style={{ width: 21, height: 21, marginLeft: 8 }}
            />
            <Text style={{ marginLeft: 30 }}>Paypal</Text>
            <View
              style={[styles.selection, { borderColor: paypalSelected ? '#EA8C12' : '#43484d' }]}></View>
          </View>
        </View>
        {/* <View
          style={styles.selectionView}>
          <View style={{ flexDirection: 'row' }}>
            <Image
              source={require('../image/ImageAmazon.png')}
              style={{ width: 26, height: 17, marginLeft: 8 }}
            />
            <Text style={{ marginLeft: 30 }}>Amazon</Text>
            <TouchableOpacity
              onPress={()=>paymentSelected('amazon')}
              style={[styles.selection,{borderColor: amazonSelected  ? '#EA8C12' : '#43484d'}]}></TouchableOpacity>
          </View>
        </View> */}
      </View>
      <View
        style={{
          width: "100%",
          height: 86,
          backgroundColor: '#FFFFFF',
          position: 'absolute', bottom: 0,
          justifyContent: "center",
          alignItems: "center"
        }}>
        <View style={{ flexDirection: 'row', }}>
          <Text
            style={{ fontWeight: 'bold', color: '#6B6B7B', marginRight: 30 }}>
            Payable Amount
          </Text>
          <View
            style={{
              backgroundColor: '#F97762',
              width: 140,
              height: 48,
              borderRadius: 10,
              marginLeft: 30,
              justifyContent: "center",
              alignItems: "center",
              marginBottom: 10


            }}>
            <TouchableOpacity
            onPress={()=>navigation.navigate('CustomWebView')}>
              <Text
                style={{
                  color: 'white',
                  textAlign: 'center',
                }}>
                Pay Now
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </>

  );
}

const styles = StyleSheet.create({
  checkboxContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  selectionView: {
    width: "100%",
    height: 48,
    backgroundColor: '#FFFFFF',
    marginTop: 20,
    borderRadius: 10,
    justifyContent: "center"
  },
  selection: {
    width: 18,
    height: 18,
    borderColor: '#43484d',
    borderRadius: 10,
    borderWidth: 3,
    position: 'absolute',
    right: 20
  }
});
