import React, {useEffect, Component, useState} from 'react';
import {RadioButton, CheckBox} from 'react-native-paper';

import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ImageBackground,
  Image,
} from 'react-native';

export default function Tutorial1({navigation}) {
  const [text, onChangeText] = React.useState(null);
  const [checked, setChecked] = React.useState('first');

  return (
    <ImageBackground
      source={require('../image/background.png')}
      style={{flex: 1, justifyContent: 'center', backgroundColor: '#612C58'}}>
      <>
        <View style={{flex: 1, alignItems:'center', justifyContent:'center'}}>
          <Image
            source={require('../image/tutorial.png')}
            style={{
              width: 335,
              height: 263,
              justifyContent: 'center',
              alignSelf: 'center'
            }}
          />
          <Text
            style={{
              color: '#fff',
              fontSize: 20,
              textAlign: 'center',
              marginTop: 60,
            }}>
            Live Training Sessions
          </Text>
          <Text
            style={{
              color: '#fff',
              fontSize: 14,
              textAlign: 'center',
              marginTop: 20,
            }}>
            Lorem Ipsum is simply dummy text of the printing{'\n'} and
            typesetting industry. the industry’s standard{'\n'} dummy text ever
            since.
          </Text>
          <View style={{flexDirection: 'row', position:'absolute', bottom: 60,}}>
            <View style={{flexDirection: 'row', marginTop: 20}}>
              <Image
                source={require('../image/live1.png')}
                style={{width: 10, height: 10, marginLeft: 10}}
              />
              <Image
                source={require('../image/live2.png')}
                style={{width: 10, height: 10, marginLeft: 10}}
              />
              <Image
                source={require('../image/live2.png')}
                style={{width: 10, height: 10, marginLeft: 10}}
              />
            </View>
            <TouchableOpacity onPress={() => navigation.navigate('Tutorial2')}
                style={{
                  width: 80,
                  height: 40,
                  backgroundColor: '#F97762',
                  justifyContent:'center',
                  borderRadius: 10,
                  marginLeft:200
                }}>
                <Text style={{textAlign: 'center', color:'white',justifyContent:"center"}}>Next</Text>
            </TouchableOpacity>
          </View>
        </View>
      </>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  checkboxContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
});
