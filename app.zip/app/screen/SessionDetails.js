
import React, { useEffect, Component, useState } from 'react';
import EvilIcons from 'react-native-vector-icons/EvilIcons';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import {
    StyleSheet,
    View,
    Text,
    TouchableOpacity,
    TextInput,
    ImageBackground,
    Image,
    ScrollView
} from 'react-native';
import * as actions from '../redux/action/actions';
import { useDispatch, useSelector } from 'react-redux';

export default function SessionDetails({ navigation }) {


    const dispatch = useDispatch();

    const { isLoading, dashboard } = useSelector((state) => ({
        isLoading: state.authReducers.isLoading,
        dashboard: state.authReducers.dashboard
    }));
    console.log('Dashborad IN seeion page', dashboard)



    return (

        <>
            <ScrollView>
                <View style={{ justifyContent: 'center', alignItems: 'center', flex: 1, paddingHorizontal: 20, }}>
                    {dashboard?.course.map((item2, index) => <View style={{ justifyContent: "center", alignSelf: "center" }} key={index}>
                        <TouchableOpacity onPress={() => null}>
                            <Image
                                style={{ width: "100%", height: 280, borderRadius: 20, marginTop: 30, }}
                                source={{ uri: `http://talc.ubicoapps.in/${item2.image}` }}
                            />
                        </TouchableOpacity>
                        <View style={{ marginHorizontal: 7, marginTop: 30 }}>
                            <Text style={{ marginBottom: 12, fontWeight: "bold" }}>{item2.title}</Text>
                            <Text style={{ marginBottom: 12, fontWeight: "bold", color: "#04A768" }}>{item2.price}</Text>
                            <Text style={{ marginBottom: 12, fontWeight: "bold" }}>{item2.description}</Text>
                            <View style={{ width: 345, height: 107, backgroundColor: "#FFFFFF", borderRadius: 10, marginBottom: 15 }}>
                                <View style={{ marginLeft: 15 }}>
                                    <Text style={{ color: "#6B6B7B", marginEnd: 11, fontSize: 13, marginTop: 15 }}>The main goal of the first coaching session is to create a plan for all of the sessions that will follow. This will establish a form of contract between coach and client. This will also be the intake session to lean about one{'\n'} another and also gather information.</Text>
                                </View>
                            </View>
                            <Text style={{ marginLeft: 10, marginBottom: 12, fontWeight: "bold" }}>Location & Contact Details</Text>
                            <View style={{ width: 345, height: 130, backgroundColor: "#FFFFFF", borderRadius: 10 }}>
                                <View style={{ marginLeft: 10 }}>
                                    <View style={{ flexDirection: "row" }}>
                                        <EvilIcons name="location" size={25} style={{ marginTop: 15 }} color="#F97762" />
                                        <Text style={{ color: "#6B6B7B", marginEnd: 11, fontSize: 13, marginTop: 15, marginLeft: 4 }}>{item2.address}</Text>
                                    </View>
                                    <View style={{ flexDirection: "row" }}>
                                        <Feather name="phone" size={18} style={{ marginTop: 15, marginLeft: 5 }} color="#F97762" />
                                        <Text style={{ color: "#6B6B7B", marginEnd: 11, fontSize: 12, marginTop: 15, marginLeft: 13 }}>{item2.contact_number}</Text>
                                    </View>
                                    <View style={{ flexDirection: "row" }}>
                                        <MaterialCommunityIcons name="email-outline" size={20} style={{ marginTop: 15, marginLeft: 5 }} color="#F97762" />
                                        <Text style={{ color: "#6B6B7B", marginEnd: 11, fontSize: 12, marginTop: 15, marginLeft: 13 }}>{item2.contact_email}</Text>
                                    </View>
                                </View>
                            </View>
                        </View>
                    </View>
                    )}
                </View>


                <View style={{ flexDirection: "row", marginTop: 20, justifyContent: "center", alignItems: "center", backgroundColor: "#FFFFFF" }}>
                    <View style={{ backgroundColor: "#F97762", width: "80%", height: 50, borderRadius: 10, }}>
                        <TouchableOpacity onPress={() => navigation.navigate('SelectDateTimes')}>
                            <Text style={{ color: 'white', textAlign: "center", marginTop: 12 }}>Book Now</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </ScrollView>
        </>
    );
};

const styles = StyleSheet.create({
    checkboxContainer: {
        flexDirection: "row",
        marginBottom: 20,
    },

});

