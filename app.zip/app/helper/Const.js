export const BASE_URL = 'http://talc.ubicoapps.in'
export const URL = `${BASE_URL}/api/`;
export const HEADER = { "Content-Type": "application/json" };
